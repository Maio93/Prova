
import org.apache.spark.api.java.*;
import org.apache.spark.api.java.function.*;

import scala.Tuple2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;

public class Spark {

    static List<String> prefix; //Lista per contenere i prefissi
    static Map<String, Integer> results; //HashMap per contenere le proprietà e quante volte vengono utilizzate
    static JavaRDD<String> logData;//RDD contenete tutti i dati
    static JavaSparkContext sc;

    public Spark() {

        SparkConf conf = new SparkConf().setAppName("Project Spark").setMaster("local[4]");
        sc = new JavaSparkContext(conf);

    }

    public Map<String, Integer> read_RDF(String path) {
        logData = sc.textFile(path);
        results = new HashMap<String, Integer>();
        //estraggo i prefissi togliendo gli URI
        prefix = extract_prefix(logData);

        //conto le proprietà
        count_property(logData);

        sc.close();
        return results;
    }

    public Map<String, Integer> read_RDF_ttl(String path) {
        logData = sc.textFile(path);
        results = new HashMap<String, Integer>();

        count_property_ttl(logData);
        sc.close();
        return results;
    }

    public Map<String, Integer> read_Text(String path) {
        logData = sc.textFile(path);
        results = new HashMap<String, Integer>();
        final Character[] punteggiatura = {'.', ',', ';', ':', '!', '"', '\'', '/', '?', '<', '>', '(', ')', '[', ']', '{', '}', '='};

        //tolgo la punteggiatura dal testo
        logData = refine_text(Arrays.asList(punteggiatura));

        count(logData);

        sc.close();
        return results;
    }

    /*
	 * metodo che estrae i prefissi
	 * i prefissi sono quelli che vengono preceduti dalla scritta xmlns
	 * escludo il prefisso "rdf" perchè rappresenta i nodi e non le proprietà
     */
    private static List<String> extract_prefix(JavaRDD<String> dataPrefix) {
        JavaRDD<String> prefix = dataPrefix.filter(new Function<String, Boolean>() {
            public Boolean call(String s) {
                s = s.trim();
                return (s.startsWith("xmlns"));
            }
        });

        prefix = prefix.map(new Function<String, String>() {
            public String call(String s) {
                String p = s.substring(s.indexOf(":") + 1, s.indexOf("="));
                if (!(p.equals("rdf"))) {
                    return p;
                } else {
                    return null;
                }
            }
        });

        return prefix.collect();
    }

    private static void count_property_ttl(JavaRDD<String> data) {
        data = data.map(new Function<String, String>() {
            public String call(String s) {
                String prop = s.split(" ")[1];
                return prop.substring(1, prop.length() - 1);
            }
        });

        data = data.map(new Function<String, String>() {
            public String call(String s) {
                int i = s.lastIndexOf("/");
                return s.substring(i + 1);
            }
        });

        count(data);
    }

    /* 
	 * Metodo che prepara le singole stringhe distinguendo
	 * i tag normali ("<"), i tag di chiusura ("</")
	 * e i tag mal indentati, cioè le stringhe che non iniziano con >.
	 * Il tutto viene passato al metodo extract_property che estrae le proprietà
     */
    private static void count_property(JavaRDD<String> Data) {

        logData = Data.map(new Function<String, String>() {
            public String call(String s) {
                s = s.trim();
                if (s.startsWith("<") && !(s.startsWith("</"))) {
                    if (s.endsWith(">")) {
                        return extract_property(s.substring(1, s.length() - 1));
                    } else {
                        return extract_property(s.substring(1));
                    }
                } else {
                    return " ";
                }
            }
        });

        count(logData);
    }

    /*
	 * Metodo che estrae la proprietà.
	 * La proprietà si trova all'inizio del tag,
	 * quindi la stringa viene splittata
	 * prima in base a se ci sono altri tag, cioè è presenta (>),
	 * poi in base agli spazi e infine in base a ":" 
         * in modo da distinguere il prefisso e il nome della proprietà
     */
    private static String extract_property(String s) {
        if (s.contains(">")) {
            s = s.split(">")[0];
        }

        s = s.split(" ")[0];

        String property[] = s.split(":");

        if (prefix.contains(property[0])) {
            return property[1];
        } else {
            return " ";
        }

    }

    /*
        * Metodo per contare gli elementi di un RDD.
        * Inizialmente viene creato un pairRDD con valore 1 per ogni elemento
        * poi gli elementi con chiavi uguali vengono uniti e il loro valori vengono sommati.
        * Infine il risultato dell'unione degli elementi uguali viene messo in results
     */
    private static void count(JavaRDD<String> data) {

        JavaRDD<String> result = data;

        JavaPairRDD<String, Integer> pairs = result.mapToPair(new PairFunction<String, String, Integer>() {
            public Tuple2<String, Integer> call(String s) {
                return new Tuple2<String, Integer>(s, 1);
            }
        });

        JavaPairRDD<String, Integer> counts = pairs.reduceByKey(new Function2<Integer, Integer, Integer>() {
            public Integer call(Integer a, Integer b) {
                return a + b;
            }
        });

        counts.foreach(new VoidFunction<Tuple2<String, Integer>>() {
            public void call(Tuple2<String, Integer> t) {
                results.put(t._1, t._2);
            }
        });
    }

    /*
        * Metodo che elemina la punteggiatura del testo da analizzare
        * e poi lo divide in base agli sapzi
     */
    private static JavaRDD<String> refine_text(List<Character> punt) {

        JavaRDD<String> newlogData = logData.map(new Function<String, String>() {
            public String call(String s) {
                String new_s = "";
                for (int i = 0; i < (s.length() - 1); i++) {
                    if (punt.contains(s.charAt(i))) {
                        if (i < (s.length() - 2)) {
                            if (s.charAt(i + 1) != ' ') {
                                new_s = new_s + " ";
                            }
                        }
                    } else {
                        new_s = new_s + s.charAt(i);
                    }
                }
                return new_s;
            }
        });

        JavaRDD<String> words = newlogData.flatMap(new FlatMapFunction<String, String>() {
            public Iterable<String> call(String s) {
                return Arrays.asList(s.split(" "));
            }
        });

        JavaRDD<String> result = words.filter(new Function<String, Boolean>() {
            public Boolean call(String s) {
                return !(s.equals(" "));
            }
        });

        return result;
    }
}
