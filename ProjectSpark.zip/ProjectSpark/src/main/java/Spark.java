import org.apache.spark.api.java.*;
import org.apache.spark.api.java.function.*;

import scala.Tuple2;

import java.io.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;

public class Spark {

	static List<String> prefix; //ArrayList per contenere i prefissi
	static Map<String, Integer> results; //HashMap per contenere le proprietà e quante volte vengono utilizzate
	static JavaRDD<String> logData;
	static JavaSparkContext sc;
	
	public Spark(String path) {
		
		SparkConf conf = new SparkConf().setAppName("Project Spark").setMaster("local[4]");
		sc = new JavaSparkContext(conf);
		logData = sc.textFile(path);//RDD contenete tutti i dati
		
	}
	
	public Map<String, Integer> start() {
		results = new HashMap<String, Integer>();
		//estraggo i prefissi togliendo gli URI
		prefix = extract_prefix(logData);
		
		//conto le proprietà
		count_property(logData);
		
		conta_parole(logData);
		
		sc.close();
		return results;
	}
        
        
	public Map<String, Integer> Anlysis_Text() {
            results = new HashMap<String, Integer>();
            final Character[] punteggiatura = {'.',',', ';', ':', '!', '"','\'', '/', '?', '<', '>','(',')','[',']','{','}','='};
            
            //tolgo la punteggiatura dal testo
            logData = raffina_text(Arrays.asList(punteggiatura));
            
            conta_parole(logData);
            
            sc.close();
            return results;
        }
	/*
	 * metodo che estrae i prefissi
	 * i prefissi sono quelli che vengono preceduti dalla scritta xmlns
	 * escludo il prefisso "rdf" perchè rappresenta i nodi e non le proprietà (credo)
	 */
	private static List<String> extract_prefix(JavaRDD<String> dataPrefix) {
		JavaRDD<String> prefix = dataPrefix.filter(new Function<String, Boolean>() {
                public Boolean call(String s){
                    s = s.trim();
                    return (s.startsWith("xmlns"));
                }
            });
            
            prefix = prefix.map(new Function<String, String>() {
                public String call(String s){
                    String p = s.substring(s.indexOf(":") + 1, s.indexOf("="));
                    if(!(p.equals("rdf")))
                        return p;
                    else
                        return null;
                }
            });
            
            return prefix.collect();
	}
	
	/* 
	 * Metodo che prepara le singole stringhe distinguendo
	 * i tag normali ("<"), i tag di chiusura ("</")
	 * e i tag mal indentati, cioè le stringhe che non iniziano con <.
	 * Il tutto viene passato al metodo extract_property che le inserisce in results
	 */
	private static void count_property(JavaRDD<String> Data) {
            
            logData = Data.map(new Function<String, String> () {
               public String call(String s) {
                   s = s.trim();
				if(s.startsWith("<") && !(s.startsWith("</"))){
					if(s.endsWith(">"))
						return extract_property(s.substring(1, s.length()-1));
					else
						return extract_property(s.substring(1));
				}
                                else
                                    return " ";
               }
            });
	}
	
	/*
	 * Metodo che estrae la proprietà e la va inserire in results
	 * o incrementando il contatore o creando un nuovo campo.
	 * La proprietà si trova all'inizio del tag,
	 * quindi la stringa viene splittata
	 * prima in base a se ci sono altri tag, cioè è presenta (>),
	 * poi in base agli spazi per isolare la proprietà,
	 * infine in base a ":" in modo da riconoscere il prefisso e il nome della proprietà
	 */
	private static String extract_property(String s){
		if(s.contains(">"))
			s = s.split(">")[0];
		
		s = s.split(" ")[0];
		
		String property[] = s.split(":");
		
		if(prefix.contains(property[0])){		
			return property[1];
		}
                else
                    return " ";
			
	}
        
        private static void conta_parole(JavaRDD<String> data){
		
		JavaRDD<String> result = data;
		
		JavaRDD<String> words = result.flatMap(new FlatMapFunction<String, String>(){
			public Iterable<String> call(String s) { return Arrays.asList(s.split(" "));}
		});
		
		JavaPairRDD<String, Integer> pairs = words.mapToPair(new PairFunction<String, String, Integer>() {
			  public Tuple2<String, Integer> call(String s) { return new Tuple2<String, Integer>(s, 1); }
		});
			
		JavaPairRDD<String, Integer> counts = pairs.reduceByKey(new Function2<Integer, Integer, Integer>() {
			  public Integer call(Integer a, Integer b) { return a + b; }
		});
				
		counts.foreach(new VoidFunction<Tuple2<String, Integer>>(){
			public void call(Tuple2<String, Integer> t) { results.put(t._1, t._2);}
		});
	}
        
        private static JavaRDD<String> raffina_text(List<Character> punt){
                       
            JavaRDD<String>newlogData = logData.map(new Function<String, String>() {
                public String call(String s){
                    String new_s = "";
                    for (int  i = 0; i < (s.length() - 1); i++){
                        if(punt.contains(s.charAt(i))){
                            if(i < (s.length() - 2)){
                                if(s.charAt(i+1) != ' ')
                                    new_s = new_s + " ";
                            }
                        }
                        else
                            new_s = new_s + s.charAt(i);
                    }
                    return new_s;
                }
            });
            
            JavaRDD<String> words = newlogData.flatMap(new FlatMapFunction<String, String>(){
			public Iterable<String> call(String s) { return Arrays.asList(s.split(" "));}
            });
            
            JavaRDD<String> result = words.filter(new Function<String, Boolean>() {
               public Boolean call(String s){
                   return !(s.equals(" "));
               } 
            });
            
            return result;
        }
}